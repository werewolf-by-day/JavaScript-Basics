var meaningOfLife = 42;
var greatestYear = 1982;
var weeksLeftOfBoot = 13;
var asteroidNavOdds = 3720;
var daily = ('coding for daaays');
var eats = ('fruit snacks');
var sunday = ('game it up & chill it out');
var codingIsLife = true;
var soMuchFreeTime = false;
var restOfMyLife;

console.log("The Meaning of Life: ", meaningOfLife);
console.log(greatestYear, "was indeed the greatest year ever.");
console.log("There are " + weeksLeftOfBoot + " weeks left of the bootcamp.");
console.log("The odds of successfully navigating an asteroid field is " +
asteroidNavOdds + " to 1.");
console.log("My average day now consists of the following: " + daily + ".");
console.log("While coding for hours, " + eats + " are a must.");
console.log("When Sunday rolls around, it's time to " + sunday + ".");
console.log("Coding is life: " + codingIsLife + ".");
console.log("I have sooo much free time on my hands right now: " + soMuchFreeTime + ".");
console.log("My current life plans after boot: " + restOfMyLife + ".");
